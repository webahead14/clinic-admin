import style from "./style.module.css";
import Complete from "../../Complete";
function AddClient(props) {
  return (
    <div>
      <h1>AddClient</h1>
    </div>
  );
}

export default AddClient;
