import style from './style.module.css'

function ClientList(props) {
    return (
        <div>
            <h1>ClientList</h1>
        </div>
    )
}

export default ClientList