import style from "./style.module.css";

function ClientPage(props) {
  return (
    <div>
      <h1>ClientPage</h1>
    </div>
  );
}

export default ClientPage;
