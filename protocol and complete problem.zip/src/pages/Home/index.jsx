import style from './style.module.css'
import { Button } from 'antd'

function Home(props) {
    return (
        <div>
            <h1>Home</h1>
            <Button type="primary">Click me bro!</Button>
        </div>
    )
}

export default Home