import style from './style.module.css'

function ProtocolList(props) {
    return (
        <div>
            <h1>ProtocolList</h1>
        </div>
    )
}

export default ProtocolList