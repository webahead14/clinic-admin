import style from './style.module.css'

function ProtocolPage(props) {
    return (
        <div>
            <h1>ProtocolPage</h1>
        </div>
    )
}

export default ProtocolPage