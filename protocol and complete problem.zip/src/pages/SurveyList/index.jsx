import style from './style.module.css'

function SurveyList(props) {
    return (
        <div>
            <h1>SurveyList</h1>
        </div>
    )
}

export default SurveyList