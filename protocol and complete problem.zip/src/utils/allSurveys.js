const options = [
  {
    id: 1,
    value: "PCL-5",
  },
  {
    id: 2,
    value: "GAD",
  },
  {
    id: 3,
    value: "PHQ",
  },
  {
    id: 4,
    value: "PGI-S",
  },
];
export default options;
